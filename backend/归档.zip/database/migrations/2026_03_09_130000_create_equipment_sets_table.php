<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('equipment_sets', function (Blueprint $table): void {
            $table->string('id', 64)->primary();
            $table->string('name', 255);
            $table->unsignedInteger('max_pieces')->default(2);
            $table->json('thresholds')->nullable();
            $table->boolean('is_enabled')->default(true);
            $table->unsignedInteger('sort_order')->default(0);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('equipment_sets');
    }
};

