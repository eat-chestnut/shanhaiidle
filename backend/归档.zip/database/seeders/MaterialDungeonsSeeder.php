<?php

namespace Database\Seeders;

use App\Models\MaterialDungeon;
use App\Models\MaterialDungeonDropGroup;
use App\Support\MaterialDungeonSupport;
use Illuminate\Database\Seeder;

class MaterialDungeonsSeeder extends Seeder
{
    public function run(): void
    {
        $definitions = [
            [
                'dungeon_id' => 'dungeon_craft',
                'name' => '堂庭采玉台',
                'dungeon_type' => 'craft',
                'unlock_level' => 20,
                'display_rewards' => ['桂木', '棪木', '白玉髓', '水玉晶', '赤金砂', '白金砂', '青雘石', '箕尾镇脉石', '终章材料'],
                'layers' => [
                    ['layer' => 1, 'recommended_power' => 2200, 'group_id' => 'mdg_dungeon_craft_l1_drop', 'name' => '堂庭采玉台 第1层掉落', 'rewards' => ['桂木', '棪木', '基础打造材料']],
                    ['layer' => 2, 'recommended_power' => 5200, 'group_id' => 'mdg_dungeon_craft_l2_drop', 'name' => '堂庭采玉台 第2层掉落', 'rewards' => ['白玉髓', '水玉晶', '基础打造材料']],
                    ['layer' => 3, 'recommended_power' => 9800, 'group_id' => 'mdg_dungeon_craft_l3_drop', 'name' => '堂庭采玉台 第3层掉落', 'rewards' => ['赤金砂', '白金砂', '鹿蜀纹角碎片']],
                    ['layer' => 4, 'recommended_power' => 18200, 'group_id' => 'mdg_dungeon_craft_l4_drop', 'name' => '堂庭采玉台 第4层掉落', 'rewards' => ['青雘石', '箕尾镇脉石', '终章材料']],
                ],
                'stamina_cost' => 10,
                'daily_limit' => 6,
                'description' => '主要产出基础打造材料与矿石材料，是1—60级锻造的底层资源来源。',
                'sort_order' => 10,
                'is_enabled' => true,
            ],
            [
                'dungeon_id' => 'dungeon_star',
                'name' => '招摇祝余圃',
                'dungeon_type' => 'star',
                'unlock_level' => 20,
                'display_rewards' => ['star_stone_t1_common', 'star_stone_t2_common', 'star_stone_t3_common', 'star_stone_t4_common'],
                'layers' => [
                    ['layer' => 1, 'recommended_power' => 2400, 'group_id' => 'mdg_dungeon_star_l1_drop', 'name' => '招摇祝余圃 第1层掉落', 'rewards' => ['star_stone_t1_common']],
                    ['layer' => 2, 'recommended_power' => 9200, 'group_id' => 'mdg_dungeon_star_l2_drop', 'name' => '招摇祝余圃 第2层掉落', 'rewards' => ['star_stone_t1_common', 'star_stone_t2_common']],
                    ['layer' => 3, 'recommended_power' => 14800, 'group_id' => 'mdg_dungeon_star_l3_drop', 'name' => '招摇祝余圃 第3层掉落', 'rewards' => ['star_stone_t2_common', 'star_stone_t3_common']],
                    ['layer' => 4, 'recommended_power' => 21000, 'group_id' => 'mdg_dungeon_star_l4_drop', 'name' => '招摇祝余圃 第4层掉落', 'rewards' => ['star_stone_t3_common', 'star_stone_t4_common']],
                ],
                'stamina_cost' => 10,
                'daily_limit' => 6,
                'description' => '产出升星材料，对应1—3、4—6、7—8、9—10星的完整成长线。',
                'sort_order' => 20,
                'is_enabled' => true,
            ],
            [
                'dungeon_id' => 'dungeon_blueprint',
                'name' => '亶爰秘禁',
                'dungeon_type' => 'blueprint',
                'unlock_level' => 30,
                'display_rewards' => ['bp_fragment_nanshan', '白猿王图纸碎片', '猨翼图纸碎片', 'bp_set_lushu_40', 'bp_set_xuangui_40', 'bp_set_migu_40', 'bp_set_chiyu_40', 'bp_set_qingqiu_40', 'bp_fragment_qingqiu', 'bp_set_lushu_60', 'bp_set_qingqiu_60', '60级主武器图纸'],
                'layers' => [
                    ['layer' => 1, 'recommended_power' => 6200, 'group_id' => 'mdg_dungeon_blueprint_l1_drop', 'name' => '亶爰秘禁 第1层掉落', 'rewards' => ['bp_fragment_nanshan', '白猿王图纸碎片', '猨翼图纸碎片']],
                    ['layer' => 2, 'recommended_power' => 9800, 'group_id' => 'mdg_dungeon_blueprint_l2_drop', 'name' => '亶爰秘禁 第2层掉落', 'rewards' => ['bp_set_lushu_40', 'bp_set_xuangui_40', 'bp_set_migu_40']],
                    ['layer' => 3, 'recommended_power' => 15000, 'group_id' => 'mdg_dungeon_blueprint_l3_drop', 'name' => '亶爰秘禁 第3层掉落', 'rewards' => ['bp_set_chiyu_40', 'bp_set_qingqiu_40', 'bp_fragment_qingqiu']],
                    ['layer' => 4, 'recommended_power' => 22000, 'group_id' => 'mdg_dungeon_blueprint_l4_drop', 'name' => '亶爰秘禁 第4层掉落', 'rewards' => ['bp_set_lushu_60', 'bp_set_qingqiu_60', '60级主武器图纸']],
                ],
                'stamina_cost' => 12,
                'daily_limit' => 5,
                'description' => '产出各阶段图纸碎片与部分完整图纸，用于打造与升阶前置。',
                'sort_order' => 30,
                'is_enabled' => true,
            ],
            [
                'dungeon_id' => 'dungeon_boss_mat',
                'name' => '杻阳守脉战',
                'dungeon_type' => 'boss',
                'unlock_level' => 40,
                'display_rewards' => ['boss_mark_nanshan', '招摇印记', '堂庭印记', '猨翼印记', '杻阳印记', '旋龟印', '旋龟核心', '柢山印记', '鯥王核心', '护身符兑换材料', '青丘印记', '箕尾印记', '青丘核心', '镇脉核心'],
                'layers' => [
                    ['layer' => 1, 'recommended_power' => 10800, 'group_id' => 'mdg_dungeon_boss_l1_drop', 'name' => '杻阳守脉战 第1层掉落', 'rewards' => ['boss_mark_nanshan', '招摇印记', '堂庭印记', '猨翼印记']],
                    ['layer' => 2, 'recommended_power' => 13200, 'group_id' => 'mdg_dungeon_boss_l2_drop', 'name' => '杻阳守脉战 第2层掉落', 'rewards' => ['杻阳印记', '旋龟印', '旋龟核心']],
                    ['layer' => 3, 'recommended_power' => 16800, 'group_id' => 'mdg_dungeon_boss_l3_drop', 'name' => '杻阳守脉战 第3层掉落', 'rewards' => ['柢山印记', '鯥王核心', '护身符兑换材料']],
                    ['layer' => 4, 'recommended_power' => 23000, 'group_id' => 'mdg_dungeon_boss_l4_drop', 'name' => '杻阳守脉战 第4层掉落', 'rewards' => ['青丘印记', '箕尾印记', '青丘核心', '镇脉核心']],
                ],
                'stamina_cost' => 15,
                'daily_limit' => 4,
                'description' => '产出印记、核心与护身符兑换材料，是40级后高阶配方与终章成长的重要资源来源。',
                'sort_order' => 40,
                'is_enabled' => true,
            ],
            [
                'dungeon_id' => 'dungeon_gem',
                'name' => '基山秘藏',
                'dungeon_type' => 'gem',
                'unlock_level' => 40,
                'display_rewards' => ['赤晶石', '沧澜石', '青木石', '属性宝石碎片·白蓝', '鹿蜀纹石', '迷榖风晶', '技能宝石碎片', '赤鱬内珠', '旋龟甲石', 'gem_skill_guanguan_seal', '白金髓', '灌灌羽晶', '高阶技能宝石碎片', 'gem_skill_jiwei_seal'],
                'layers' => [
                    ['layer' => 1, 'recommended_power' => 11200, 'group_id' => 'mdg_dungeon_gem_l1_drop', 'name' => '基山秘藏 第1层掉落', 'rewards' => ['赤晶石', '沧澜石', '青木石', '属性宝石碎片·白蓝']],
                    ['layer' => 2, 'recommended_power' => 13800, 'group_id' => 'mdg_dungeon_gem_l2_drop', 'name' => '基山秘藏 第2层掉落', 'rewards' => ['鹿蜀纹石', '迷榖风晶', '技能宝石碎片']],
                    ['layer' => 3, 'recommended_power' => 17600, 'group_id' => 'mdg_dungeon_gem_l3_drop', 'name' => '基山秘藏 第3层掉落', 'rewards' => ['赤鱬内珠', '旋龟甲石', 'gem_skill_guanguan_seal']],
                    ['layer' => 4, 'recommended_power' => 23800, 'group_id' => 'mdg_dungeon_gem_l4_drop', 'name' => '基山秘藏 第4层掉落', 'rewards' => ['白金髓', '灌灌羽晶', '高阶技能宝石碎片', 'gem_skill_jiwei_seal']],
                ],
                'stamina_cost' => 12,
                'daily_limit' => 5,
                'description' => '产出属性宝石、技能宝石与对应碎片，40级后正式进入宝石成长线。',
                'sort_order' => 50,
                'is_enabled' => true,
            ],
            [
                'dungeon_id' => 'dungeon_refine',
                'name' => '箕尾洗髓坛',
                'dungeon_type' => 'refine',
                'unlock_level' => 50,
                'display_rewards' => ['refine_sand_basic', 'refine_core_advanced', 'equipment_essence', 'purple_refine_dust'],
                'layers' => [
                    ['layer' => 1, 'recommended_power' => 17000, 'group_id' => 'mdg_dungeon_refine_l1_drop', 'name' => '箕尾洗髓坛 第1层掉落', 'rewards' => ['refine_sand_basic', 'equipment_essence']],
                    ['layer' => 2, 'recommended_power' => 19200, 'group_id' => 'mdg_dungeon_refine_l2_drop', 'name' => '箕尾洗髓坛 第2层掉落', 'rewards' => ['refine_sand_basic', 'refine_core_advanced', 'equipment_essence']],
                    ['layer' => 3, 'recommended_power' => 24600, 'group_id' => 'mdg_dungeon_refine_l3_drop', 'name' => '箕尾洗髓坛 第3层掉落', 'rewards' => ['refine_core_advanced', 'purple_refine_dust', 'equipment_essence']],
                ],
                'stamina_cost' => 15,
                'daily_limit' => 4,
                'description' => '50级开放的洗练材料副本，承担紫色洗练与终章 build 微调资源。',
                'sort_order' => 60,
                'is_enabled' => true,
            ],
        ];

        $validDungeonIds = [];
        $validGroupIds = [];

        foreach ($definitions as $definition) {
            $validDungeonIds[] = $definition['dungeon_id'];
            $layerRules = [];

            foreach ($definition['layers'] as $index => $layerDefinition) {
                $validGroupIds[] = $layerDefinition['group_id'];

                MaterialDungeonDropGroup::query()->updateOrCreate(
                    ['group_id' => $layerDefinition['group_id']],
                    [
                        'name' => $layerDefinition['name'],
                        'rewards' => $this->rewardEntries($layerDefinition['rewards']),
                        'description' => null,
                        'sort_order' => ($definition['sort_order'] * 10) + ($index + 1),
                        'is_enabled' => true,
                    ],
                );

                $layerRules[] = [
                    'layer' => $layerDefinition['layer'],
                    'drop_group_id' => $layerDefinition['group_id'],
                    'first_clear_reward_group_id' => null,
                    'recommended_power' => $layerDefinition['recommended_power'],
                    'sort' => $index + 1,
                ];
            }

            MaterialDungeon::query()->updateOrCreate(
                ['dungeon_id' => $definition['dungeon_id']],
                [
                    'name' => $definition['name'],
                    'dungeon_type' => $definition['dungeon_type'],
                    'unlock_level' => $definition['unlock_level'],
                    'display_rewards' => $this->displayRewards($definition['display_rewards']),
                    'layer_rules' => $layerRules,
                    'stamina_cost' => $definition['stamina_cost'],
                    'daily_limit' => $definition['daily_limit'],
                    'description' => $definition['description'],
                    'sort_order' => $definition['sort_order'],
                    'is_enabled' => $definition['is_enabled'],
                ],
            );
        }

        MaterialDungeon::query()->whereNotIn('dungeon_id', $validDungeonIds)->delete();
        MaterialDungeonDropGroup::query()->whereNotIn('group_id', $validGroupIds)->delete();
    }

    /**
     * @param  array<int, string>  $itemIds
     * @return array<int, string>
     */
    private function displayRewards(array $itemIds): array
    {
        $resolved = [];

        foreach ($itemIds as $itemId) {
            $resolvedItemId = MaterialDungeonSupport::resolveLegacyItemId($itemId);
            if ($resolvedItemId === null) {
                continue;
            }

            $resolved[] = $resolvedItemId;
        }

        return array_values(array_unique($resolved));
    }

    /**
     * @param  array<int, string>  $itemIds
     * @return array<int, array<string, int|float|string>>
     */
    private function rewardEntries(array $itemIds): array
    {
        $entries = [];

        foreach ($this->displayRewards($itemIds) as $index => $itemId) {
            $entries[] = [
                'item_id' => $itemId,
                'count_min' => 1,
                'count_max' => 1,
                'probability' => 1,
                'sort' => $index + 1,
            ];
        }

        return $entries;
    }
}
