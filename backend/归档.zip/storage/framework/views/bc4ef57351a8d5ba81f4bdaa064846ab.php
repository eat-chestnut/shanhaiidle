<?php echo value($html); ?>

<?php /**PATH /Users/mumu/game/ShanhaiIdle/backend/vendor/filament/support/resources/views/anonymous-partial.blade.php ENDPATH**/ ?>