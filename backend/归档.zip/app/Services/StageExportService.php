<?php

namespace App\Services;

use App\Models\AppSetting;
use App\Models\Stage;
use App\Models\StageExport;
use App\Support\AdminOptions;
use App\Support\StageConfigSupport;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use RuntimeException;

class StageExportService
{
    private const EXPORT_DIR = 'app/exports';

    private const LATEST_FILE_NAME = 'stages_v1.json';

    private const PROJECT_DATA_FILE = '../data/stages_v1.json';

    public function export(): array
    {
        $stages = $this->buildStages();
        $payloadWithoutMeta = [
            'stages' => $stages,
        ];
        $version = ExportMetaService::getNextVersion('stages');
        $historyMaxVersion = (int) (StageExport::query()->max('version') ?? 0);
        if ($version <= $historyMaxVersion) {
            $version = $historyMaxVersion + 1;
            AppSetting::setValue('export_version:stages', $version);
        }
        $meta = ExportMetaService::makeMeta('stages', $version, $payloadWithoutMeta);
        $sha256 = (string) ($meta['sha256'] ?? '');
        $exportedAt = (string) ($meta['exported_at'] ?? now()->format('Y-m-d H:i:s'));

        $result = DB::transaction(function () use ($stages, $payloadWithoutMeta, $version, $meta, $sha256, $exportedAt): array {
            $payload = ['meta' => $meta] + $payloadWithoutMeta;

            $json = json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            if ($json === false) {
                throw new RuntimeException('导出序列化失败。');
            }

            $dir = storage_path(self::EXPORT_DIR);
            if (! File::exists($dir)) {
                File::makeDirectory($dir, 0755, true);
            }

            $latestAbsolutePath = $dir . DIRECTORY_SEPARATOR . self::LATEST_FILE_NAME;
            $versionFileName = "stages_v1_{$version}.json";
            $versionAbsolutePath = $dir . DIRECTORY_SEPARATOR . $versionFileName;
            $projectDataPath = base_path(self::PROJECT_DATA_FILE);

            File::put($latestAbsolutePath, $json);
            File::put($versionAbsolutePath, $json);
            File::put($projectDataPath, $json);

            StageExport::query()->create([
                'version' => $version,
                'file_path' => 'exports/' . $versionFileName,
                'sha256' => $sha256,
            ]);

            AppSetting::setValue('stages_version', $version);
            AppSetting::setValue('current_version', $version);

            $this->cleanupHistory(20);

            return [
                'version' => $version,
                'sha256' => $sha256,
                'count' => count($stages),
                'latest_path' => $latestAbsolutePath,
                'version_path' => $versionAbsolutePath,
                'project_data_path' => $projectDataPath,
                'exported_at' => $exportedAt,
            ];
        });

        return $result;
    }

    public function rollbackToVersion(int $version): array
    {
        $record = StageExport::query()->where('version', $version)->first();
        if (! $record) {
            throw new RuntimeException("未找到版本 {$version}。");
        }

        $source = storage_path('app/' . ltrim((string) $record->file_path, '/'));
        if (! is_file($source)) {
            throw new RuntimeException("版本文件不存在：{$record->file_path}");
        }

        $dir = storage_path(self::EXPORT_DIR);
        if (! File::exists($dir)) {
            File::makeDirectory($dir, 0755, true);
        }

        $target = $dir . DIRECTORY_SEPARATOR . self::LATEST_FILE_NAME;
        $projectDataPath = base_path(self::PROJECT_DATA_FILE);
        File::copy($source, $target);
        File::copy($source, $projectDataPath);

        AppSetting::setValue('current_version', $version);

        return [
            'version' => $version,
            'sha256' => (string) $record->sha256,
            'latest_path' => $target,
            'project_data_path' => $projectDataPath,
        ];
    }

    public function history(): Collection
    {
        return StageExport::query()
            ->orderByDesc('version')
            ->get();
    }

    private function buildStages(): array
    {
        return Stage::query()
            ->where('is_enabled', true)
            ->orderBy('sort_order')
            ->get()
            ->map(function (Stage $stage): array {
                return [
                    'id' => (string) $stage->id,
                    'name' => (string) $stage->name,
                    'unlock_min_level' => (int) $stage->unlock_min_level,
                    'difficulties' => $this->normalizeDifficulties($stage->difficulties),
                ];
            })
            ->values()
            ->all();
    }

    private function normalizeDifficulties(mixed $raw): array
    {
        return array_map(function (array $row): array {
            return [
                'difficulty_name' => (string) $row['difficulty_name'],
                'recommended_power' => (int) $row['recommended_power'],
                'spawn_interval' => $row['spawn_interval'],
                'onscreen_limit' => (int) $row['onscreen_limit'],
                'spawn_radius' => (int) $row['spawn_radius'],
                'normal_monsters' => $this->normalizeMonsterPool($row['normal_monsters'] ?? []),
                'elite_monsters' => $this->normalizeMonsterPool($row['elite_monsters'] ?? []),
                'boss_monsters' => $this->normalizeMonsterPool($row['boss_monsters'] ?? []),
                'elite_spawn_rule' => is_array($row['elite_spawn_rule'] ?? null) ? $row['elite_spawn_rule'] : null,
                'boss_spawn_rule' => is_array($row['boss_spawn_rule'] ?? null) ? $row['boss_spawn_rule'] : null,
            ];
        }, StageConfigSupport::normalizeDifficulties($raw));
    }

    private function normalizeMonsterPool(mixed $raw): array
    {
        $rows = [];

        foreach (is_array($raw) ? $raw : [] as $row) {
            if (! is_array($row)) {
                continue;
            }

            $monsterId = trim((string) ($row['monster_id'] ?? ''));
            if ($monsterId === '') {
                continue;
            }

            $rows[] = [
                'monster_id' => $monsterId,
                'monster_name' => AdminOptions::monsterName($monsterId),
                'weight' => max(0, (int) ($row['weight'] ?? 0)),
            ];
        }

        return array_values($rows);
    }

    private function cleanupHistory(int $keep): void
    {
        if ($keep < 1) {
            return;
        }

        $expired = StageExport::query()
            ->orderByDesc('version')
            ->skip($keep)
            ->take(PHP_INT_MAX)
            ->get();

        foreach ($expired as $record) {
            $path = storage_path('app/' . ltrim((string) $record->file_path, '/'));
            if (is_file($path)) {
                @unlink($path);
            }
            $record->delete();
        }
    }
}
