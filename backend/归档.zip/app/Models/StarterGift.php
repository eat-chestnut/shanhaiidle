<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StarterGift extends Model
{
    protected $fillable = [
        'gift_id',
        'unlock_level',
        'gift_name',
        'gift_role',
        'open_copy',
        'rewards',
        'must_claim',
        'is_free',
        'icon_path',
        'banner_path',
        'sort_order',
        'is_enabled',
    ];

    protected $casts = [
        'unlock_level' => 'integer',
        'rewards' => 'array',
        'must_claim' => 'boolean',
        'is_free' => 'boolean',
        'sort_order' => 'integer',
        'is_enabled' => 'boolean',
    ];

    public function setRewardsAttribute(mixed $value): void
    {
        $rows = [];

        foreach ((array) $value as $row) {
            if (! is_array($row)) {
                continue;
            }

            $itemId = trim((string) ($row['item_id'] ?? ''));
            if ($itemId === '') {
                continue;
            }

            $itemName = trim((string) ($row['item_name'] ?? ''));
            if ($itemName === '') {
                $itemName = (string) Item::query()->where('id', $itemId)->value('name');
            }

            $optionalGroup = trim((string) ($row['optional_group'] ?? ''));
            $rewardType = trim((string) ($row['reward_type'] ?? ''));
            if (! in_array($rewardType, ['fixed', 'choice'], true)) {
                $rewardType = $optionalGroup !== '' ? 'choice' : 'fixed';
            }

            $entry = [
                'reward_type' => $rewardType,
                'item_id' => $itemId,
                'item_name' => $itemName,
                'count' => max(1, (int) ($row['count'] ?? 1)),
            ];

            if ($rewardType === 'choice' && $optionalGroup !== '') {
                $entry['optional_group'] = $optionalGroup;
            }

            $rows[] = $entry;
        }

        $this->attributes['rewards'] = json_encode(array_values($rows), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }
}
