<?php

namespace App\Filament\Resources\MaterialDungeonResource\Pages;

use App\Filament\Resources\MaterialDungeonResource;
use App\Support\MaterialDungeonSupport;
use Filament\Resources\Pages\CreateRecord;

class CreateMaterialDungeon extends CreateRecord
{
    protected static string $resource = MaterialDungeonResource::class;

    protected function mutateFormDataBeforeCreate(array $data): array
    {
        $data['display_rewards'] = MaterialDungeonSupport::normalizeDisplayRewardsOrFail($data['display_rewards'] ?? []);
        $data['layer_rules'] = MaterialDungeonSupport::normalizeLayerRulesOrFail($data['layer_rules'] ?? []);

        return $data;
    }
}
