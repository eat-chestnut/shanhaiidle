extends Node

const SAVE_PATH := "user://map_progress.json"

func _ready() -> void:
	load_data()

func load_data() -> void:
	save_data()

func save_data() -> void:
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f == null:
		return
	f.store_string("{}")
